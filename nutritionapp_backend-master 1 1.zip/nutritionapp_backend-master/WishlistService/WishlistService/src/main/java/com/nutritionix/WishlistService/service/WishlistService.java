package com.nutritionix.WishlistService.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.nutritionix.WishlistService.model.Stock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nutritionix.WishlistService.model.BrandedProduct;
import com.nutritionix.WishlistService.model.UserWishlist;
import com.nutritionix.WishlistService.repository.WishListRepository;

@Service
public class WishlistService {
	@Autowired
	WishListRepository wishListRepository;
	
	public List<Stock> addProdctToWishList(
			Stock product, String username) {
		System.out.println(product.toString());
		Optional<UserWishlist> userWishList = wishListRepository.findById(username);
		if(userWishList.isEmpty()) {
			List<Stock> products = new ArrayList<>();
			products.add(product);
			for(Stock prod: products) {
				System.out.println(prod.toString());
			}
			UserWishlist wishList = new UserWishlist(username,products);
			
			wishListRepository.save(wishList);
			return wishList.getProducts();
		}else {
			UserWishlist wishList = userWishList.get();
			List<Stock> products = wishList.getProducts();
			Optional<Stock> existProductCheck = products.stream()
	                .filter(p -> p.getName().equals(product.getName()))
	                .findFirst();
			if(existProductCheck.isEmpty())
				products.add(product);
			for(Stock prod: products) {
				System.out.println(prod.toString());
			}
			wishList.setProducts(products);
			wishListRepository.save(wishList);
			return wishList.getProducts();
		}
	
		
	}
	
	public List<Stock> getUserProducts(String username) throws Exception{
		Optional<UserWishlist> userWishList = wishListRepository.findById(username);
		if(userWishList.isEmpty()) {
			throw new Exception("User doesnot exist");
		}
		UserWishlist wishList = userWishList.get();
		return wishList.getProducts();
	}
	
	public List<Stock> deleteWishListProduct(String itemId, String username) throws Exception {
		Optional<UserWishlist> userWishList = wishListRepository.findById(username);
		if(userWishList.isEmpty()) {
			throw new Exception("User doesnot exist");
		}
		UserWishlist wishList = userWishList.get();
		List<Stock> products = wishList.getProducts();
//		
		products.removeIf(prod -> itemId.equals(prod.getName()));
		wishList.setProducts(products);
		wishListRepository.save(wishList);
		
		return wishList.getProducts();
	}
	
	
}
