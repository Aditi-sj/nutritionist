package com.nutritionix.NutritionService.controller;

import com.nutritionix.NutritionService.model.Stock;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/stocks")
public class NutritionController {

    @GetMapping("")
    public List<Stock> getStcokBasedOnCountry(@RequestParam(defaultValue = "India") String country) throws JSONException {
        List<Stock> stocks=new ArrayList<>();
        String stockUrl = "https://api.twelvedata.com/stocks?country="+country;
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpGet getRequest = new HttpGet(stockUrl);
        getRequest.setHeader("Content-Type", "application/json");
        String str="";

        try{
            HttpResponse response = httpClient.execute(getRequest);
            HttpEntity entity = response.getEntity();
            str = EntityUtils.toString(entity);
        }catch (IOException e){
            e.printStackTrace();
        }
        JSONObject jsonObject = new JSONObject(str);
        JSONArray data = (JSONArray) jsonObject.get("data");

        for(int i=0; i<data.length();i++){
            Stock stock=new Stock();
            JSONObject product = data.getJSONObject(i);
            System.out.println(product);
            stock.setCountry(product.getString("country"));
            stock.setName(product.getString("name"));
            stock.setCurrency(product.getString("currency"));
            stock.setSymbol(product.getString("symbol"));
            stock.setType(product.getString("type"));
            stock.setMic_code(product.getString("mic_code"));
            stock.setExchange(product.getString("exchange"));
            stocks.add(stock);
        }


        return stocks;
    }

}
