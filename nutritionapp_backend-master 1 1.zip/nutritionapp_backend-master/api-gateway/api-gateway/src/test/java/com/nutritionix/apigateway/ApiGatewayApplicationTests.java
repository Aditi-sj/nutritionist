package com.nutritionix.apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootTest
@EnableDiscoveryClient
class ApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
