package com.nutritionix.UserProfile.exception;

public class UsernameAlreadyExistsException extends Exception{
	public UsernameAlreadyExistsException(String s) {
		super(s);
	}
}
