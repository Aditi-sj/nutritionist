package com.nutritionix.UserProfile.exception;

public class UsernameAndPasswordNotNullException extends Exception{
	public UsernameAndPasswordNotNullException(String s){
		super(s);
	}
}
