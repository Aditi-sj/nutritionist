package com.nutritionix.UserProfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
